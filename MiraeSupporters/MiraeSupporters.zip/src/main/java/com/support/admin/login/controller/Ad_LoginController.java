package com.support.admin.login.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.support.admin.login.service.Ad_LoginService;
import com.support.admin.login.vo.Ad_LoginVo;

@Controller
@RequestMapping(value="/ad_login")
public class Ad_LoginController {

	@Autowired
	private Ad_LoginService ad_loginService;

	@Autowired
	ModelAndView mav;

	@RequestMapping(value="/confirm", method=RequestMethod.POST)
	public ModelAndView loginConfirm(Ad_LoginVo vo) {
		Ad_LoginVo lvo = ad_loginService.loginConfirm(vo);
		

		if (lvo == null) {
			mav.addObject("fail", "�α��ο� �����߽��ϴ�");
			mav.setViewName("admin/login");
		} else {
			mav.addObject("success",lvo);
			mav.setViewName("redirect:/sponsor/list");
		}
		return mav;

	}
}
