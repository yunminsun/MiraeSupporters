package com.support.admin.login.dao;

import com.support.admin.login.vo.Ad_LoginVo;

public interface Ad_LoginDao {

	public Ad_LoginVo loginConfirm(Ad_LoginVo vo);
}
