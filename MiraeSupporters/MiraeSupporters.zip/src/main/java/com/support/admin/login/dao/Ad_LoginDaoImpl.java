package com.support.admin.login.dao;


import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.support.admin.login.vo.Ad_LoginVo;

public class Ad_LoginDaoImpl implements Ad_LoginDao {
	
	@Autowired 
	private SqlSessionTemplate session;

	@Override
	public Ad_LoginVo loginConfirm(Ad_LoginVo vo) {
		return session.selectOne("loginConfirm", vo);
		
	}

}
