package com.support.admin.login.service;

import com.support.admin.login.vo.Ad_LoginVo;

public interface Ad_LoginService {
	public Ad_LoginVo loginConfirm(Ad_LoginVo vo);
}
