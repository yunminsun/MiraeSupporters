package com.support.admin.login.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.support.admin.login.dao.Ad_LoginDao;
import com.support.admin.login.vo.Ad_LoginVo;

@Service
public class Ad_LoginServiceImpl implements Ad_LoginService {

	@Autowired
	private Ad_LoginDao ad_loginDao;

	@Override
	public Ad_LoginVo loginConfirm(Ad_LoginVo vo) {
		Ad_LoginVo lvo = ad_loginDao.loginConfirm(vo);
		return lvo;

	}

}
