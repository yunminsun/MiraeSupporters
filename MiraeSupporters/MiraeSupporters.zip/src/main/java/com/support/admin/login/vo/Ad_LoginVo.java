package com.support.admin.login.vo;

public class Ad_LoginVo {

	private int a_num;
	private String a_id;
	private String a_pw;
	private String a_name;
	private int offset;
	private int noOfRecords;
	private String keyword;

	public Ad_LoginVo() {
		super();
	}

	public Ad_LoginVo(int a_num, String a_id, String a_pw, String a_name) {
		super();
		this.a_num = a_num;
		this.a_id = a_id;
		this.a_pw = a_pw;
		this.a_name = a_name;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public int getOffset() {
		return offset;
	}

	public void setOffset(int offset) {
		this.offset = offset;
	}

	public int getNoOfRecords() {
		return noOfRecords;
	}

	public void setNoOfRecords(int noOfRecords) {
		this.noOfRecords = noOfRecords;
	}

	public int getA_num() {
		return a_num;
	}

	public void setA_num(int a_num) {
		this.a_num = a_num;
	}

	public String getA_id() {
		return a_id;
	}

	public void setA_id(String a_id) {
		this.a_id = a_id;
	}

	public String getA_pw() {
		return a_pw;
	}

	public void setA_pw(String a_pw) {
		this.a_pw = a_pw;
	}

	public String getA_name() {
		return a_name;
	}

	public void setA_name(String a_name) {
		this.a_name = a_name;
	}

}
