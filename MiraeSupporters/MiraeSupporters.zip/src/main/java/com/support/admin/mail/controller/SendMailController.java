package com.support.admin.mail.controller;

import java.util.List;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.support.admin.mail.service.SendMailService;
import com.support.admin.mail.vo.SendMailVo;

@Controller
@RequestMapping(value = "/sendmail")
public class SendMailController {

	

	@Autowired
	ModelAndView mav;
/*
	@Autowired
	private JavaMailSender mailSender;
*/
	@RequestMapping(value = "/mailform")
	public ModelAndView sendMailForm() {
		mav.setViewName("/admin/mailsend");
		return mav;
	}

	
}
