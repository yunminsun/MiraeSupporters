package com.support.admin.mail.dao;

import java.util.List;

import com.support.admin.mail.vo.SendMailVo;

public interface SendMailDao {

	public SendMailVo givemail(int s_num);
	public List<SendMailVo> sendMail(SendMailVo vo);
}
