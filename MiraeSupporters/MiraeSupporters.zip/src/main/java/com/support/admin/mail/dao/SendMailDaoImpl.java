package com.support.admin.mail.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.support.admin.mail.vo.SendMailVo;

@Repository
public class SendMailDaoImpl implements SendMailDao {

	@Autowired
	private SqlSessionTemplate session;

	@Override
	public List<SendMailVo> sendMail(SendMailVo vo) {
		return session.selectList("sendMail", vo);
	}
	@Override
	public SendMailVo givemail(int s_num) {
		return session.selectOne("givemail", s_num);
	}
}
