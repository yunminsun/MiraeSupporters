package com.support.admin.mail.service;

import java.util.List;

import com.support.admin.mail.vo.SendMailVo;

public interface SendMailService {
	public List<SendMailVo> sendMail(SendMailVo vo);
	public SendMailVo givemail(int s_num);
}
