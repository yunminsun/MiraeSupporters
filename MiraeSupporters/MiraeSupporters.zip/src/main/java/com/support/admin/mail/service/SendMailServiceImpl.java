package com.support.admin.mail.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.support.admin.mail.dao.SendMailDao;
import com.support.admin.mail.vo.SendMailVo;

@Service
public class SendMailServiceImpl implements SendMailService {

	@Autowired
	private SendMailDao sendMailDao;

	@Override
	public List<SendMailVo> sendMail(SendMailVo vo) {
		List<SendMailVo> sm = sendMailDao.sendMail(vo);
		return sm;
	}
	@Override
	public SendMailVo givemail(int s_num) {
		return sendMailDao.givemail(s_num);
	}
}
