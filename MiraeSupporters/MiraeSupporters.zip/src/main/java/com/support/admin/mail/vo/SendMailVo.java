package com.support.admin.mail.vo;

public class SendMailVo {
	private String tomail;// �����»��
	private String s_email;// �޴»������
	private String m_title; // ��������
	private String m_content;// ���ϳ���
	private String m_category;// ���� ������
	private String mailaddr;

	public SendMailVo() {
		super();
	}

	public String getMailaddr() {
		return mailaddr;
	}

	public void setMailaddr(String mailaddr) {
		this.mailaddr = mailaddr;
	}

	public String getS_email() {
		return s_email;
	}

	public void setS_email(String s_email) {
		this.s_email = s_email;
	}

	public String getTomail() {
		return tomail;
	}

	public void setTomail(String tomail) {
		this.tomail = tomail;
	}

	public String getM_category() {
		return m_category;
	}

	public void setM_category(String m_category) {
		this.m_category = m_category;
	}

	public String getM_title() {
		return m_title;
	}

	public void setM_title(String m_title) {
		this.m_title = m_title;
	}

	public String getM_content() {
		return m_content;
	}

	public void setM_content(String m_content) {
		this.m_content = m_content;
	}

}
