package com.support.admin.mainpage.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value = "/main")
public class MainPageController {

	@Autowired
	ModelAndView mav;

	@RequestMapping(value = "/main")
	public ModelAndView mainPage() {
		mav.setViewName("admin/main");
		return mav;
	}
}
