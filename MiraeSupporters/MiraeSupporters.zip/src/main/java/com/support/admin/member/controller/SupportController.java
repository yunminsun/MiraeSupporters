package com.support.admin.member.controller;

import java.util.List;

import javax.mail.internet.MimeMessage;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.support.admin.board.paging.Paging;
import com.support.admin.mail.service.SendMailService;
import com.support.admin.mail.vo.SendMailVo;
import com.support.admin.member.service.SupportService;
import com.support.admin.member.vo.SupportVo;

@Controller
@RequestMapping(value = "/sponsor")
public class SupportController {

	@Autowired
	private SupportService supportService;
	@Autowired
	private SendMailService sendMailService;
	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	ModelAndView mav;

	@RequestMapping(value = "/list")
	public ModelAndView sponsorList(SupportVo vo, HttpServletRequest request) {

		int currentPageNo = 1;
		int maxPost = 10;

		if (request.getParameter("pages") != null) {
			currentPageNo = Integer.parseInt(request.getParameter("pages"));
		}
		Paging paging = new Paging(currentPageNo, maxPost);

		int offset = (paging.getCurrentPageNo() - 1) * paging.getmaxPost() + 1;
		int posts = paging.getmaxPost() + offset - 1;

		vo.setOffset(offset);
		vo.setNoOfRecords(posts);

		paging.setNumberOfRecords(supportService.memberGetCount());

		paging.makePaging();

		if (vo.getCategorysearch() == null) {
			vo.setCategorysearch("");
		}

		List<SupportVo> mvo = supportService.sponsorList(vo);

		mav.addObject("searchcategory", vo.getCategorysearch());
		mav.addObject("paging", paging);
		mav.addObject("memberList", mvo);
		mav.setViewName("/admin/memberlist");
		return mav;
	}

	@RequestMapping(value = "/sendmail")
	public ModelAndView sendMail(SendMailVo vo, HttpServletRequest request) {
		if(vo.getM_category() == "����") {
			vo.setM_category("");
		}
		String setfrom = "h0106326852453@gmail.com";
		List<SendMailVo> tomail = sendMailService.sendMail(vo); // �޴� ��� �̸���
		System.out.println(tomail.size());
		String title = vo.getM_title();// ����
		String content = vo.getM_content();// ����
		String selectnum[] = request.getParameterValues("selectnum");
		for (String s_num : selectnum) {
			tomail.add(sendMailService.givemail(Integer.parseInt(s_num)));

		}
		System.out.println(tomail.size());
		MimeMessagePreparator[] preparators = new MimeMessagePreparator[tomail.size()];
		int i = 0;
		for (final SendMailVo svo : tomail) {
			svo.setM_title(title);
			svo.setM_content(content);
			svo.setTomail(setfrom);
			preparators[i++] = new MimeMessagePreparator() {
				@Override
				public void prepare(MimeMessage mimeMessage) throws Exception {
					final MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
					helper.setFrom(svo.getTomail());
					helper.setTo(svo.getS_email());
					helper.setSubject(svo.getM_title());
					helper.setText(svo.getM_content(), true);
				}
			};
		}
		mailSender.send(preparators);

		return mav;
	}

}
