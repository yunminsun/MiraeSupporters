package com.support.admin.member.dao;

import java.util.List;

import com.support.admin.member.vo.SupportVo;

public interface SupportDao {
	public List<SupportVo> sponsorList(SupportVo vo);

	public int memberGetCount();
	
	
	
}
