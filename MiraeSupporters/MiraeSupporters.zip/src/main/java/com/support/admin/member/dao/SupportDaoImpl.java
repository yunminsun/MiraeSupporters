package com.support.admin.member.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.support.admin.member.vo.SupportVo;

@Repository
public class SupportDaoImpl implements SupportDao {

	@Autowired
	private SqlSessionTemplate session;

	@Override
	public List<SupportVo> sponsorList(SupportVo vo) {
		return session.selectList("sponsorList", vo);
	}

	@Override
	public int memberGetCount() {
		return session.selectOne("memberGetCount");
	}

}
