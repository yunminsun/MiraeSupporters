package com.support.admin.member.service;

import java.util.List;

import com.support.admin.member.vo.SupportVo;

public interface SupportService {
	public List<SupportVo> sponsorList(SupportVo vo);
	
	public int memberGetCount();

	

}
