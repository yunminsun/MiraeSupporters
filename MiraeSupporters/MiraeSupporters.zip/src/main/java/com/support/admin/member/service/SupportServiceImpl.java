package com.support.admin.member.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.support.admin.member.dao.SupportDao;
import com.support.admin.member.vo.SupportVo;

@Service
public class SupportServiceImpl implements SupportService {

	@Autowired
	private SupportDao supportDao;

	@Override
	public List<SupportVo> sponsorList(SupportVo vo) {
		List<SupportVo> mvo = supportDao.sponsorList(vo);
		return mvo;
	}
	@Override
	public int memberGetCount() {
		return supportDao.memberGetCount();
	}
	
}
