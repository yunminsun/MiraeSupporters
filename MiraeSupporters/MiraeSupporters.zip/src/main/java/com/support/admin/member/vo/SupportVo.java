package com.support.admin.member.vo;

public class SupportVo {

	private int s_num = 0; // ȸ����ȣ
	private String sc_birth = ""; // ����_�������
	private String sc_gender = ""; // ����_����
	private String so_name = ""; // ��ü_��ü��
	private String se_name = ""; // ���_�����
	private String se_businessnum = ""; // ���_����ڵ�Ϲ�ȣ
	private String s_name = ""; // �̸�
	private String s_phonenum = ""; // ����ó
	private String s_email = ""; // �̸���
	private String s_addr = ""; // �ּ�
	private String s_service = ""; // ����� ����
	private String s_servey = ""; // ��������
	private String s_agreement = ""; // ������ǿ���
	private String s_id = ""; // id
	private String s_pw = ""; // pw
	private String s_category = ""; // �Ŀ��� ����
	private String categorysearch;
	private int offset;
	private int noOfRecords;

	public SupportVo() {
		super();
	}

	public int getOffset() {
		return offset;
	}

	public void setOffset(int offset) {
		this.offset = offset;
	}

	public int getNoOfRecords() {
		return noOfRecords;
	}

	public void setNoOfRecords(int noOfRecords) {
		this.noOfRecords = noOfRecords;
	}

	public String getCategorysearch() {
		return categorysearch;
	}

	public void setCategorysearch(String categorysearch) {
		this.categorysearch = categorysearch;
	}

	public int getS_num() {
		return s_num;
	}

	public void setS_num(int s_num) {
		this.s_num = s_num;
	}

	public String getSc_birth() {
		return sc_birth;
	}

	public void setSc_birth(String sc_birth) {
		this.sc_birth = sc_birth;
	}

	public String getSc_gender() {
		return sc_gender;
	}

	public void setSc_gender(String sc_gender) {
		this.sc_gender = sc_gender;
	}

	public String getSo_name() {
		return so_name;
	}

	public void setSo_name(String so_name) {
		this.so_name = so_name;
	}

	public String getSe_name() {
		return se_name;
	}

	public void setSe_name(String se_name) {
		this.se_name = se_name;
	}

	public String getSe_businessnum() {
		return se_businessnum;
	}

	public void setSe_businessnum(String se_businessnum) {
		this.se_businessnum = se_businessnum;
	}

	public String getS_name() {
		return s_name;
	}

	public void setS_name(String s_name) {
		this.s_name = s_name;
	}

	public String getS_phonenum() {
		return s_phonenum;
	}

	public void setS_phonenum(String s_phonenum) {
		this.s_phonenum = s_phonenum;
	}

	public String getS_email() {
		return s_email;
	}

	public void setS_email(String s_email) {
		this.s_email = s_email;
	}

	public String getS_addr() {
		return s_addr;
	}

	public void setS_addr(String s_addr) {
		this.s_addr = s_addr;
	}

	public String getS_service() {
		return s_service;
	}

	public void setS_service(String s_service) {
		this.s_service = s_service;
	}

	public String getS_servey() {
		return s_servey;
	}

	public void setS_servey(String s_servey) {
		this.s_servey = s_servey;
	}

	public String getS_agreement() {
		return s_agreement;
	}

	public void setS_agreement(String s_agreement) {
		this.s_agreement = s_agreement;
	}

	public String getS_id() {
		return s_id;
	}

	public void setS_id(String s_id) {
		this.s_id = s_id;
	}

	public String getS_pw() {
		return s_pw;
	}

	public void setS_pw(String s_pw) {
		this.s_pw = s_pw;
	}

	public String getS_category() {
		return s_category;
	}

	public void setS_category(String s_category) {
		this.s_category = s_category;
	}

}
