package com.support.admin.notice.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.support.admin.notice.dao.Ad_NoticeDao;
import com.support.admin.notice.vo.Ad_NoticeVo;

@Service
public class Ad_NoticeServiceImpl implements Ad_NoticeService {

	@Autowired
	private Ad_NoticeDao ad_noticeDao;
	
	@Override
	public List<Ad_NoticeVo> noticeList(Ad_NoticeVo vo){
		List<Ad_NoticeVo> nvo = ad_noticeDao.noticeList(vo);
		return nvo;
	}
	@Override
	public int noticeGetCount() {
		return ad_noticeDao.noticeGetCount();
	}
	@Override
	public List<Ad_NoticeVo> noticeSearchList(Ad_NoticeVo vo){
		List<Ad_NoticeVo> nvo = ad_noticeDao.noticeSearchList(vo);
		return nvo;
	}
	@Override
	public List<Ad_NoticeVo> noticeKeywordSearch(Ad_NoticeVo vo){
		List<Ad_NoticeVo> nvo = ad_noticeDao.noticeKeywordSearch(vo);
		return nvo;
	}
	@Override
	public int noticeInsert(Ad_NoticeVo vo) {
		int result = ad_noticeDao.noticeInsert(vo);
		return result;
	}
	@Override
	public Ad_NoticeVo noticeDetail(Ad_NoticeVo vo) {
		Ad_NoticeVo nvo = ad_noticeDao.noticeDetail(vo);
		return nvo;
	}
	@Override
	public int noticeUpdate(Ad_NoticeVo vo) {
		int result = ad_noticeDao.noticeUpdate(vo);
		return result;
	}
	@Override
	public int noticeDelete(Ad_NoticeVo vo) {
		int result = ad_noticeDao.noticeDelete(vo);
		return result;
	}
}
