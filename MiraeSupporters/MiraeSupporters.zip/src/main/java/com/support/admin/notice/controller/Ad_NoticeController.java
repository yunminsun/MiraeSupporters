package com.support.admin.notice.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.support.admin.board.paging.Paging;
import com.support.admin.notice.Service.Ad_NoticeService;
import com.support.admin.notice.vo.Ad_NoticeVo;

@Controller
@RequestMapping(value = "/ad_notice")
public class Ad_NoticeController {

	@Autowired
	private Ad_NoticeService ad_noticeService;

	@Autowired
	ModelAndView mav;

	// �������� ����Ʈ ��� ���
	@RequestMapping(value = "/list")
	public ModelAndView noticeList(Ad_NoticeVo vo, HttpServletRequest request) {
		List<Ad_NoticeVo> nvo;
		int currentPageNo = 1;
		int maxPost = 10;

		if (request.getParameter("pages") != null) {	
			currentPageNo = Integer.parseInt(request.getParameter("pages"));
		}
		Paging paging = new Paging(currentPageNo, maxPost);

		int offset = (paging.getCurrentPageNo() - 1) * paging.getmaxPost() + 1;
		int posts = paging.getmaxPost() + offset - 1;
		

		vo.setOffset(offset);
		vo.setNoOfRecords(posts);
		
		paging.setNumberOfRecords(ad_noticeService.noticeGetCount());
		paging.makePaging();

		if (request.getParameter("searchtype") != null && request.getParameter("searchtype") != "") {
			if (request.getParameter("searchtype").equals("��ü����")) {
			
				nvo = (ArrayList<Ad_NoticeVo>) ad_noticeService.noticeList(vo);
				mav.addObject("noticeList", nvo);
				mav.addObject("searchtype", vo);
			} else if (request.getParameter("searchtype").equals("��������")) {
				
				nvo = (ArrayList<Ad_NoticeVo>) ad_noticeService.noticeSearchList(vo);
				mav.addObject("noticeList", nvo);
				mav.addObject("searchtype", vo);
			} else if (request.getParameter("searchtype").equals("��ȸ��")) {
				
				nvo = (ArrayList<Ad_NoticeVo>) ad_noticeService.noticeSearchList(vo);
				mav.addObject("noticeList", nvo);
				mav.addObject("searchtype", vo);
			}
		} else {
		
			nvo = (ArrayList<Ad_NoticeVo>) ad_noticeService.noticeList(vo);
			mav.addObject("noticeList", nvo);
		}

		

		mav.addObject("paging", paging);
		mav.addObject("admininfo", vo);
		mav.setViewName("/admin/noticeList");
		return mav;
	}

	@RequestMapping(value = "/keywordsearch")
	public ModelAndView noticeKeywordSearch(Ad_NoticeVo vo, HttpServletRequest request) {
		int currentPageNo = 1;
		int maxPost = 10;

		if (request.getParameter("pages") != null) {
			currentPageNo = Integer.parseInt(request.getParameter("pages"));
		}
		Paging paging = new Paging(currentPageNo, maxPost);

		int offset = (paging.getCurrentPageNo() - 1) * paging.getmaxPost() + 1;
		int posts = paging.getmaxPost() + offset - 1;

		vo.setOffset(offset);
		vo.setNoOfRecords(posts);
		
		paging.setNumberOfRecords(ad_noticeService.noticeGetCount());
		paging.makePaging();
		List<Ad_NoticeVo> nvo = ad_noticeService.noticeKeywordSearch(vo);
		if (nvo != null) {
			mav.addObject("noticeList", nvo);
			mav.setViewName("/admin/noticeList");
		} else {
			mav.setViewName("/admin/noticeList");
		}
		return mav;
	}

	@RequestMapping(value = "/insertform")
	public ModelAndView noticeInsertform(Ad_NoticeVo vo) {
		mav.addObject("admininfo", vo);
		mav.setViewName("/admin/noticeinsertform");
		return mav;
	}

	@RequestMapping(value = "/insert")
	public ModelAndView noticeInsert(Ad_NoticeVo vo) {
		int result = ad_noticeService.noticeInsert(vo);
		if (result == 1) {
			mav.setViewName("redirect:/ad_notice/list?a_num=" + vo.getA_num());
		} else {
			mav.addObject("fail", "������� �ٽ� �õ��� �ּ���");
			mav.setViewName("redirect:/ad_notice/insertform");
		}

		return mav;
	}

	@RequestMapping(value = "/detail")
	public ModelAndView noticeDetail(Ad_NoticeVo vo) {
		Ad_NoticeVo nvo = ad_noticeService.noticeDetail(vo);
		mav.addObject("adminnum", vo.getA_num());
		mav.addObject("noticedetail", nvo);
		mav.setViewName("/admin/noticedetail");
		return mav;
	}

	@RequestMapping(value = "/update")
	public ModelAndView noticeUpdate(Ad_NoticeVo vo) {
		int result = ad_noticeService.noticeUpdate(vo);
		if (result == 1) {
			mav.setViewName("redirect:/ad_notice/list");
		}
		return mav;
	}

	@RequestMapping(value = "/delete")
	public ModelAndView noticeDelete(Ad_NoticeVo vo) {
		int result = ad_noticeService.noticeDelete(vo);
		if (result == 1) {
			mav.setViewName("redirect:/ad_notice/list");
		}
		return mav;
	}
}
