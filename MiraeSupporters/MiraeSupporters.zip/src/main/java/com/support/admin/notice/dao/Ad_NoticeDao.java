package com.support.admin.notice.dao;

import java.util.List;

import com.support.admin.notice.vo.Ad_NoticeVo;

public interface Ad_NoticeDao {

	public List<Ad_NoticeVo> noticeList(Ad_NoticeVo vo);

	public int noticeGetCount();

	public List<Ad_NoticeVo> noticeSearchList(Ad_NoticeVo vo);

	public List<Ad_NoticeVo> noticeKeywordSearch(Ad_NoticeVo vo);

	public int noticeInsert(Ad_NoticeVo vo);

	public Ad_NoticeVo noticeDetail(Ad_NoticeVo vo);

	public int noticeUpdate(Ad_NoticeVo vo);

	public int noticeDelete(Ad_NoticeVo vo);
}
