package com.support.admin.notice.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.support.admin.notice.vo.Ad_NoticeVo;

public class Ad_NoticeDaoImpl implements Ad_NoticeDao {

	@Autowired
	private SqlSessionTemplate session;

	@Override
	public List<Ad_NoticeVo> noticeList(Ad_NoticeVo vo) {
		
		List<Ad_NoticeVo> noticeList = session.selectList("noticeList", vo);
		return noticeList;
	}

	@Override
	public int noticeGetCount() {

		return session.selectOne("noticeGetCount");
	}

	@Override
	public List<Ad_NoticeVo> noticeSearchList(Ad_NoticeVo vo) {
		return session.selectList("noticeSearchList", vo);
	}

	@Override
	public List<Ad_NoticeVo> noticeKeywordSearch(Ad_NoticeVo vo) {
		return session.selectList("noticeKeywordSearch", vo);
	}

	@Override
	public int noticeInsert(Ad_NoticeVo vo) {
		return session.insert("noticeInsert", vo);
	}

	@Override
	public Ad_NoticeVo noticeDetail(Ad_NoticeVo vo) {
		return session.selectOne("noticeDetail", vo);
	}

	@Override
	public int noticeUpdate(Ad_NoticeVo vo) {
		return session.update("noticeUpdate", vo);
	}

	@Override
	public int noticeDelete(Ad_NoticeVo vo) {
		return session.delete("noticeDelete", vo);
	}

}
