package com.support.admin.question.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.support.admin.board.paging.Paging;
import com.support.admin.login.vo.Ad_LoginVo;
import com.support.admin.question.service.Ad_QuestionService;
import com.support.admin.question.vo.Ad_QuestionVo;


@Controller
@RequestMapping(value = "/ad_question")
public class Ad_QuestionController {

	@Autowired
	private Ad_QuestionService ad_questionService;

	@Autowired
	ModelAndView mav;

	@RequestMapping(value = "/board")
	public ModelAndView questionList(Ad_LoginVo vo, HttpServletRequest request) {
		
		int currentPageNo = 1;
		int maxPost = 10;
		if (request.getParameter("pages") != null) {
			currentPageNo = Integer.parseInt(request.getParameter("pages"));
		}
		Paging paging = new Paging(currentPageNo, maxPost);

		int offset = (paging.getCurrentPageNo() - 1) * paging.getmaxPost() + 1;
		int posts = paging.getmaxPost() + offset - 1;

		vo.setOffset(offset);
		vo.setNoOfRecords(posts);
		
		if(vo.getKeyword() == null) {
			vo.setKeyword("");
		}
		List<Ad_QuestionVo> qvo = ad_questionService.questionList(vo);
		paging.setNumberOfRecords(ad_questionService.noticeGetCount());

		paging.makePaging();
		mav.addObject("keyword", vo.getKeyword());
		mav.addObject("paging", paging);
		mav.addObject("question", qvo);
		mav.addObject("adminnum", vo);
		mav.setViewName("/admin/questionlist");
		return mav;
	}

	@RequestMapping(value = "/detail")
	public ModelAndView questionDetail(Ad_QuestionVo vo, Ad_LoginVo lvo) {
		Ad_QuestionVo qvo = ad_questionService.questionDetail(vo);
		
		mav.addObject("adminnum", vo.getA_num());
		mav.addObject("question", qvo);
		mav.setViewName("/admin/questionreplyinsert");
		return mav;
	}
	@RequestMapping(value="/update")
	public ModelAndView questionUpdate(Ad_QuestionVo vo) {
		int result = ad_questionService.questionUpdate(vo);
		if(result == 1) {
			mav.setViewName("redirect:/ad_question/detail?q_num="+vo.getQ_num());
		}
		return mav;
	}
	@RequestMapping(value="/delete")
	public ModelAndView questionDelete(Ad_QuestionVo vo) {
		int result = ad_questionService.questionDelete(vo);
		if(result == 1) {
			mav.setViewName("redirect:/ad_question/board");
		}
		return mav;
	}


}
