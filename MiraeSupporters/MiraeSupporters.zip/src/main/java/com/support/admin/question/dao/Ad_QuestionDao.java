package com.support.admin.question.dao;

import java.util.List;

import com.support.admin.login.vo.Ad_LoginVo;
import com.support.admin.question.vo.Ad_QuestionVo;

public interface Ad_QuestionDao {
	public List<Ad_QuestionVo> questionList(Ad_LoginVo vo);

	public int noticeGetCount();

	public Ad_QuestionVo questionDetail(Ad_QuestionVo vo);
	public int questionUpdate(Ad_QuestionVo vo);

	public int questionDelete(Ad_QuestionVo vo);

}
