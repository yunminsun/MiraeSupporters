package com.support.admin.question.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.support.admin.login.vo.Ad_LoginVo;
import com.support.admin.question.vo.Ad_QuestionVo;


public class Ad_QuestionDaoImpl implements Ad_QuestionDao {

	@Autowired
	private SqlSessionTemplate session;

	@Override
	public List<Ad_QuestionVo> questionList(Ad_LoginVo vo) {

		return session.selectList("questionList", vo);
	}

	@Override
	public int noticeGetCount() {
		return session.selectOne("noticeGetCount");
	}

	@Override
	public Ad_QuestionVo questionDetail(Ad_QuestionVo vo) {
		return session.selectOne("questionDetail", vo);
	}
	@Override
	public int questionUpdate(Ad_QuestionVo vo) {
		return session.update("questionUpdate");
	}
	@Override
	public int questionDelete(Ad_QuestionVo vo) {
		return session.delete("questionDelete");
	}

}
