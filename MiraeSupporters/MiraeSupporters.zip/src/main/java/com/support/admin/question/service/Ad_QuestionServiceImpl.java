package com.support.admin.question.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.support.admin.login.vo.Ad_LoginVo;
import com.support.admin.question.dao.Ad_QuestionDao;
import com.support.admin.question.vo.Ad_QuestionVo;


@Service
public class Ad_QuestionServiceImpl implements Ad_QuestionService {

	@Autowired
	private Ad_QuestionDao ad_questionDao;

	@Override
	public List<Ad_QuestionVo> questionList(Ad_LoginVo vo) {
		List<Ad_QuestionVo> qvo = ad_questionDao.questionList(vo);
		return qvo;
	}
	@Override
	public int noticeGetCount() {
		return ad_questionDao.noticeGetCount();
	}

	@Override
	public Ad_QuestionVo questionDetail(Ad_QuestionVo vo) {
		Ad_QuestionVo qvo = ad_questionDao.questionDetail(vo);
		return qvo;
	}
	@Override
	public int questionUpdate(Ad_QuestionVo vo) {
		return ad_questionDao.questionUpdate(vo);
	}
	@Override
	public int questionDelete(Ad_QuestionVo vo) {
		return ad_questionDao.questionDelete(vo);
	}

}
