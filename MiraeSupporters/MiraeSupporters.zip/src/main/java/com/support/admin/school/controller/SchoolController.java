package com.support.admin.school.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.support.admin.school.service.SchoolService;
import com.support.admin.school.vo.SchoolVo;
import com.support.common.file.FileUploadUtil;

@Controller
@RequestMapping(value = "/school")
public class SchoolController {

	@Autowired
	private SchoolService schoolService;

	@Autowired
	ModelAndView mav;

	// ���� ������ ��� �޼ҵ�
	@RequestMapping(value = "/infomation")
	public ModelAndView schoolInfomation() {
		List<SchoolVo> allschool = schoolService.schoolInfomation();
		mav.addObject("allschool", allschool);
		mav.setViewName("/admin/nurseryschool");

		return mav;
	}

	// ������ ��� ������ ��� �޼ҵ�
	@RequestMapping(value = "/insertform")
	public String schoolInsert() {
		return "/admin/nurseryschoolinsert";
	}

	// ������ ��� ó�� �޼ҵ�
	@RequestMapping(value = "/insert")
	public ModelAndView schoolInsert(SchoolVo vo, HttpServletRequest request)
			throws IllegalStateException, IOException {

		System.out.println(vo.getFileparamorma() + " getFileparamorma");

		if (vo.getFileparamorma() != null && vo.getFileaddr() != null) {

			String file1 = FileUploadUtil.fileUpload(vo.getFileparamorma(), request, "school");
			String file2 = FileUploadUtil.fileUpload(vo.getFileaddr(), request, "school");
			String file3 = FileUploadUtil.fileUpload(vo.getFileinsidea(), request, "school");
			String file4 = FileUploadUtil.fileUpload(vo.getFileinsideb(), request, "school");
			String file5 = FileUploadUtil.fileUpload(vo.getFileinsidec(), request, "school");

			vo.setI_file_paramorma(file1);
			vo.setI_file_addr(file2);
			vo.setI_file_inside_a(file3);
			vo.setI_file_inside_b(file4);
			vo.setI_file_inside_c(file5);
		}

		int result = schoolService.schoolInsert(vo);

		if (result == 1) {
			mav.addObject("result", "������ ��ϼ���");
			mav.setViewName("/admin/nurseryschoolinsert");
		} else {
			mav.addObject("result", "������ ��Ͻ���");
			mav.setViewName("/admin/nurseryschoolinsert");
		}

		return mav;
	}

	// �ϳ��� ���������� ��� �޼ҵ�
	@RequestMapping(value = "/selectone")
	public ModelAndView schoolSelectOne(SchoolVo vo) {
		SchoolVo svo = schoolService.schoolSelectOne(vo);
		mav.addObject("school", svo);
		mav.setViewName("/admin/nurseryschooldetail");
		return mav;
	}

	// ������ ���� ���� �޼ҵ�
	@RequestMapping(value = "/update")
	public ModelAndView schoolUpdate(SchoolVo vo, HttpServletRequest request)
			throws IllegalStateException, IOException {

		String file1 = FileUploadUtil.fileUpload(vo.getFileparamorma(), request, "school");
		String file2 = FileUploadUtil.fileUpload(vo.getFileaddr(), request, "school");
		String file3 = FileUploadUtil.fileUpload(vo.getFileinsidea(), request, "school");
		String file4 = FileUploadUtil.fileUpload(vo.getFileinsideb(), request, "school");
		String file5 = FileUploadUtil.fileUpload(vo.getFileinsidec(), request, "school");

		if (file1 != null) {
			vo.setI_file_paramorma(file1);
		} else if (file2 != null) {
			vo.setI_file_addr(file2);
		} else if (file3 != null) {
			vo.setI_file_inside_a(file3);
		} else if (file4 != null) {
			vo.setI_file_inside_b(file4);
		} else if (file5 != null) {
			vo.setI_file_inside_c(file5);
		}

		int result = schoolService.schoolUpdate(vo);

		if (result == 1) {
			mav.setViewName("redirect:/school/infomation");
		} else {
			mav.addObject("fail", "������ �����߽��ϴ�.");
			String url = "redirect:/school/selectone?i_num=" + vo.getI_num();
			mav.setViewName(url);
		}
		return mav;
	}

	// ������ ���� ���� �޼ҵ�

	@RequestMapping(value = "/delete")

	public ModelAndView schoolDelete(SchoolVo vo) {
		int result = schoolService.schoolDelete(vo);

		if (result == 1) {
			mav.setViewName("redirect:/school/infomation");
		} else {
			mav.addObject("fail", "������ �����߽��ϴ�.");
			String url = "redirect:/school/selectone?i_num=" + vo.getI_num();
			mav.setViewName(url);
		}
		return mav;
	}

}
