package com.support.admin.school.dao;

import java.util.List;

import com.support.admin.school.vo.SchoolVo;

public interface SchoolDao {

	public int schoolInsert(SchoolVo vo);

	public List<SchoolVo> schoolInfomation();

	public SchoolVo schoolSelectOne(SchoolVo vo);
	
	public int schoolDelete(SchoolVo vo);
	
	public int schoolUpdate(SchoolVo vo);

}
