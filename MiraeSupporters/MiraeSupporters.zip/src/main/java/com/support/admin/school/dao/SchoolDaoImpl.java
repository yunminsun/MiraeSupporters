package com.support.admin.school.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.support.admin.school.vo.SchoolVo;

@Repository
public class SchoolDaoImpl implements SchoolDao {

	@Autowired
	SqlSessionTemplate session;

	@Override
	public int schoolInsert(SchoolVo vo) {
		return session.insert("schoolInsert", vo);
	}

	@Override
	public List<SchoolVo> schoolInfomation() {
		return session.selectList("schoolInfomation");
	}
	
	@Override
	public SchoolVo schoolSelectOne(SchoolVo vo) {
		return session.selectOne("schoolSelectOne", vo);
	}
	@Override
	public int schoolDelete(SchoolVo vo) {
		return session.delete("schoolDelete", vo);
	}
@Override
public int schoolUpdate(SchoolVo vo) {
	return session.update("schoolUpdate", vo);
}

}
