package com.support.admin.school.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.support.admin.school.dao.SchoolDao;
import com.support.admin.school.vo.SchoolVo;

@Service
public class SchoolServiceImpl implements SchoolService {

	@Autowired
	private SchoolDao schoolDao;

	@Override
	public int schoolInsert(SchoolVo vo) {
		int result = schoolDao.schoolInsert(vo);
		return result;
	}

	@Override
	public List<SchoolVo> schoolInfomation() {
		List<SchoolVo> allschool = schoolDao.schoolInfomation();
		return allschool;
	}
	
	@Override
	public SchoolVo schoolSelectOne(SchoolVo vo) {
		SchoolVo svo = schoolDao.schoolSelectOne(vo);
		return svo;
	}
	
	@Override
	public int schoolDelete(SchoolVo vo) {
		int result = schoolDao.schoolDelete(vo);
		return result;
		
	}
	@Override
	public int schoolUpdate(SchoolVo vo) {
		int result = schoolDao.schoolUpdate(vo);
		return result;
	}

}
