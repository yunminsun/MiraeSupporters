package com.support.admin.school.vo;

import org.springframework.web.multipart.MultipartFile;

public class SchoolVo {

	private int i_num =0;
	private String i_name ="";
	private String i_officenum="";
	private String i_content="";
	private String i_owner="";
	private String i_facilitiestel="";
	private String i_max="";
	private String i_children="";
	private String i_addr="";
	private String i_bank="";
	private String i_account="";

	// ���Ͼ��ε� �� DB�� ���� �� ���ڿ� ����
	private String i_file_paramorma="";
	private String i_file_addr="";
	private String i_file_inside_a="";
	private String i_file_inside_b="";
	private String i_file_inside_c="";

	// ���Ͼ��ε� �� ������ ���� MultipartFile ����
	private MultipartFile fileparamorma;
	private MultipartFile fileaddr;
	private MultipartFile fileinsidea;
	private MultipartFile fileinsideb;
	private MultipartFile fileinsidec;

	public MultipartFile getFileparamorma() {
		return fileparamorma;
	}

	public void setFileparamorma(MultipartFile fileparamorma) {
		this.fileparamorma = fileparamorma;
	}

	public MultipartFile getFileaddr() {
		return fileaddr;
	}

	public void setFileaddr(MultipartFile fileaddr) {
		this.fileaddr = fileaddr;
	}

	public MultipartFile getFileinsidea() {
		return fileinsidea;
	}

	public void setFileinsidea(MultipartFile fileinsidea) {
		this.fileinsidea = fileinsidea;
	}

	public MultipartFile getFileinsideb() {
		return fileinsideb;
	}

	public void setFileinsideb(MultipartFile fileinsideb) {
		this.fileinsideb = fileinsideb;
	}

	public MultipartFile getFileinsidec() {
		return fileinsidec;
	}

	public void setFileinsidec(MultipartFile fileinsidec) {
		this.fileinsidec = fileinsidec;
	}

	public SchoolVo() {
		super();
	}

	public int getI_num() {
		return i_num;
	}

	public void setI_num(int i_num) {
		this.i_num = i_num;
	}

	public String getI_name() {
		return i_name;
	}

	public void setI_name(String i_name) {
		this.i_name = i_name;
	}

	public String getI_officenum() {
		return i_officenum;
	}

	public void setI_officenum(String i_officenum) {
		this.i_officenum = i_officenum;
	}

	public String getI_content() {
		return i_content;
	}

	public void setI_content(String i_content) {
		this.i_content = i_content;
	}

	public String getI_owner() {
		return i_owner;
	}

	public void setI_owner(String i_owner) {
		this.i_owner = i_owner;
	}

	public String getI_facilitiestel() {
		return i_facilitiestel;
	}

	public void setI_facilitiestel(String i_facilitiestel) {
		this.i_facilitiestel = i_facilitiestel;
	}

	public String getI_max() {
		return i_max;
	}

	public void setI_max(String i_max) {
		this.i_max = i_max;
	}

	public String getI_children() {
		return i_children;
	}

	public void setI_children(String i_children) {
		this.i_children = i_children;
	}

	public String getI_addr() {
		return i_addr;
	}

	public void setI_addr(String i_addr) {
		this.i_addr = i_addr;
	}

	public String getI_bank() {
		return i_bank;
	}

	public void setI_bank(String i_bank) {
		this.i_bank = i_bank;
	}

	public String getI_account() {
		return i_account;
	}

	public void setI_account(String i_account) {
		this.i_account = i_account;
	}

	public String getI_file_paramorma() {
		return i_file_paramorma;
	}

	public void setI_file_paramorma(String i_file_paramorma) {
		this.i_file_paramorma = i_file_paramorma;
	}

	public String getI_file_addr() {
		return i_file_addr;
	}

	public void setI_file_addr(String i_file_addr) {
		this.i_file_addr = i_file_addr;
	}

	public String getI_file_inside_a() {
		return i_file_inside_a;
	}

	public void setI_file_inside_a(String i_file_inside_a) {
		this.i_file_inside_a = i_file_inside_a;
	}

	public String getI_file_inside_b() {
		return i_file_inside_b;
	}

	public void setI_file_inside_b(String i_file_inside_b) {
		this.i_file_inside_b = i_file_inside_b;
	}

	public String getI_file_inside_c() {
		return i_file_inside_c;
	}

	public void setI_file_inside_c(String i_file_inside_c) {
		this.i_file_inside_c = i_file_inside_c;
	}

}
