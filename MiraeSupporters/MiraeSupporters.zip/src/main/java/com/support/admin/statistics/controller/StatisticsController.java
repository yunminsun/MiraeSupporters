package com.support.admin.statistics.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.support.admin.statistics.service.StatisticsService;
import com.support.admin.statistics.vo.AreaChartVo;
import com.support.admin.statistics.vo.StatisticsVo;

@Controller
@RequestMapping(value = "/statistics")
public class StatisticsController {

	@Autowired
	private StatisticsService statisticsService;

	@Autowired
	ModelAndView mav;

	@RequestMapping(value = "/main")
	public ModelAndView statisticsMain() {
		mav.setViewName("/admin/statistics");
		return mav;
	}

	@RequestMapping(value = "/todayspon")
	public @ResponseBody Map<String, Object> todaySpon() {
		Map<String, Object> jsonMap = new HashMap<String, Object>();
		StatisticsVo svo = new StatisticsVo();

		List<StatisticsVo> stavo = new ArrayList<StatisticsVo>();
		stavo.add(statisticsService.totalMoney());
		stavo.add(statisticsService.todayMoney());
		stavo.add(statisticsService.indivcount());
		stavo.add(statisticsService.comcount());
		stavo.add(statisticsService.groupcount());
		stavo.add(statisticsService.monthMoney());

		if (stavo.get(1) == null) {
			stavo.remove(1);
			int today = 0;
			svo = new StatisticsVo(stavo.get(0).getTotalmoney(), today, stavo.get(1).getIndividualcount(),
					stavo.get(2).getCompanycount(), stavo.get(3).getGroupcount(), stavo.get(4).getMonthmoney());
		} else {
			svo = new StatisticsVo(stavo.get(0).getTotalmoney(), stavo.get(1).getTodaymoney(),
					stavo.get(2).getIndividualcount(), stavo.get(3).getCompanycount(), stavo.get(4).getGroupcount(),
					stavo.get(5).getMonthmoney());
		}

		jsonMap.put("total", svo.getTotalmoney());
		jsonMap.put("today", svo.getTodaymoney());
		jsonMap.put("indiv", svo.getIndividualcount());
		jsonMap.put("com", svo.getCompanycount());
		jsonMap.put("group", svo.getGroupcount());
		jsonMap.put("month", svo.getMonthmoney());

		return jsonMap;
	}

	@RequestMapping(value = "/areachart")
	public @ResponseBody Map<String, Object> areaChart() {
		Map<String, Object> jsonMap = new HashMap<String, Object>();
		List<AreaChartVo> actvo = new ArrayList<AreaChartVo>();
		
		actvo.add(statisticsService.getdays());
		List<AreaChartVo> acvo = statisticsService.indivmoney();
		
		jsonMap.put("today", actvo.get(0).getToday());
		jsonMap.put("minusone", actvo.get(0).getMinusone());
		jsonMap.put("minustwo", actvo.get(0).getMinustwo());
		jsonMap.put("minusthree", actvo.get(0).getMinusthree());
		jsonMap.put("minusfour", actvo.get(0).getMinusfour());
		jsonMap.put("minusfive", actvo.get(0).getMinusfive());
		jsonMap.put("minussix", actvo.get(0).getMinussix());
		jsonMap.put("dayone", acvo.get(0).getMoney());
		jsonMap.put("daytwo", acvo.get(1).getMoney());
		jsonMap.put("daythree", acvo.get(2).getMoney());
		jsonMap.put("dayfour", acvo.get(3).getMoney());
		jsonMap.put("dayfive", acvo.get(4).getMoney());
		jsonMap.put("daysix", acvo.get(5).getMoney());
		jsonMap.put("dayseven", acvo.get(6).getMoney());
		
		
		return jsonMap;
	}

}
