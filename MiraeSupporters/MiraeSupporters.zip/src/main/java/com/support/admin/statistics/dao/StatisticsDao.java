package com.support.admin.statistics.dao;

import java.util.List;

import com.support.admin.statistics.vo.AreaChartVo;
import com.support.admin.statistics.vo.StatisticsVo;

public interface StatisticsDao {
	public StatisticsVo totalMoney();

	public StatisticsVo todayMoney();

	public StatisticsVo indivcount();

	public StatisticsVo comcount();

	public StatisticsVo groupcount();

	public StatisticsVo monthMoney();
	
	public AreaChartVo getdays();
	public List<AreaChartVo> indivmoney();
}
