package com.support.admin.statistics.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.support.admin.statistics.vo.AreaChartVo;
import com.support.admin.statistics.vo.StatisticsVo;

@Repository
public class StatisticsDaoImpl implements StatisticsDao {

	@Autowired
	private SqlSessionTemplate session;

	@Override
	public AreaChartVo getdays() {

		return session.selectOne("getdays");
	}

	@Override
	public List<AreaChartVo> indivmoney() {

		return session.selectList("indivmoney");
	}

	@Override
	public StatisticsVo totalMoney() {

		return session.selectOne("totalMoney");
	}

	@Override
	public StatisticsVo todayMoney() {
		return session.selectOne("todayMoney");
	}

	@Override
	public StatisticsVo indivcount() {

		return session.selectOne("indivcount");
	}

	@Override
	public StatisticsVo comcount() {

		return session.selectOne("comcount");
	}

	@Override
	public StatisticsVo groupcount() {

		return session.selectOne("groupcount");
	}

	@Override
	public StatisticsVo monthMoney() {
		return session.selectOne("monthMoney");
	}
}
