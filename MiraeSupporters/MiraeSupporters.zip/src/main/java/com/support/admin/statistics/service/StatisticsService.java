package com.support.admin.statistics.service;

import java.util.List;

import com.support.admin.statistics.vo.AreaChartVo;
import com.support.admin.statistics.vo.StatisticsVo;

public interface StatisticsService {
	public StatisticsVo totalMoney();
	public StatisticsVo todayMoney();
	public StatisticsVo indivcount();
	public StatisticsVo comcount();
	public StatisticsVo groupcount();
	public StatisticsVo monthMoney();
	
	public AreaChartVo getdays();
	public List<AreaChartVo> indivmoney();
	
	
}
