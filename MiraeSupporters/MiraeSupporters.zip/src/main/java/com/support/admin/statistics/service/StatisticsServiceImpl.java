package com.support.admin.statistics.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.support.admin.statistics.dao.StatisticsDao;
import com.support.admin.statistics.vo.AreaChartVo;
import com.support.admin.statistics.vo.StatisticsVo;

@Service
public class StatisticsServiceImpl implements StatisticsService {

	@Autowired
	private StatisticsDao statisticsDao;

	@Override
	public AreaChartVo getdays() {
		AreaChartVo actvo = statisticsDao.getdays();
		return actvo;
	}

	@Override
	public List<AreaChartVo> indivmoney() {
		List<AreaChartVo> actvo = statisticsDao.indivmoney();
		return actvo;
	}
	@Override
	public StatisticsVo totalMoney() {
		StatisticsVo svo = statisticsDao.totalMoney();
		return svo;
	}

	@Override
	public StatisticsVo todayMoney() {
		StatisticsVo svo = statisticsDao.todayMoney();
		return svo;
	}

	@Override
	public StatisticsVo indivcount() {
		StatisticsVo svo = statisticsDao.indivcount();
		return svo;
	}

	@Override
	public StatisticsVo comcount() {
		StatisticsVo svo = statisticsDao.comcount();
		return svo;
	}

	@Override
	public StatisticsVo groupcount() {
		StatisticsVo svo = statisticsDao.groupcount();
		return svo;
	}

	@Override
	public StatisticsVo monthMoney() {
		StatisticsVo svo = statisticsDao.monthMoney();
		return svo;
	}
}
