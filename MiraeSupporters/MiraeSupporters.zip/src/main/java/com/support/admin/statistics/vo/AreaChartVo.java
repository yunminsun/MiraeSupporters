package com.support.admin.statistics.vo;

public class AreaChartVo {
	private String today;
	private String minusone;
	private String minustwo;
	private String minusthree;
	private String minusfour;
	private String minusfive;
	private String minussix;
	private int money;

	public AreaChartVo() {
		super();
	}

	
	
	public int getMoney() {
		return money;
	}

	public void setMoney(int money) {
		this.money = money;
	}

	public String getToday() {
		return today;
	}

	public void setToday(String today) {
		this.today = today;
	}

	public String getMinusone() {
		return minusone;
	}

	public void setMinusone(String minusone) {
		this.minusone = minusone;
	}

	public String getMinustwo() {
		return minustwo;
	}

	public void setMinustwo(String minustwo) {
		this.minustwo = minustwo;
	}

	public String getMinusthree() {
		return minusthree;
	}

	public void setMinusthree(String minusthree) {
		this.minusthree = minusthree;
	}

	public String getMinusfour() {
		return minusfour;
	}

	public void setMinusfour(String minusfour) {
		this.minusfour = minusfour;
	}

	public String getMinusfive() {
		return minusfive;
	}

	public void setMinusfive(String minusfive) {
		this.minusfive = minusfive;
	}

	public String getMinussix() {
		return minussix;
	}

	public void setMinussix(String minussix) {
		this.minussix = minussix;
	}

	
}