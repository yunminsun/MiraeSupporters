package com.support.admin.statistics.vo;

public class StatisticsVo {

	private int totalmoney;
	private int todaymoney;
	private int individualcount;
	private int companycount;
	private int groupcount;
	private int monthmoney;

	public StatisticsVo() {
		super();
	}

	public StatisticsVo(int totalmoney, int todaymoney, int individualcount, int companycount, int groupcount,
			int monthmoney) {
		super();
		this.totalmoney = totalmoney;
		this.todaymoney = todaymoney;
		this.individualcount = individualcount;
		this.companycount = companycount;
		this.groupcount = groupcount;
		this.monthmoney = monthmoney;
	}

	public int getMonthmoney() {
		return monthmoney;
	}

	public void setMonthmoney(int monthmoney) {
		this.monthmoney = monthmoney;
	}

	public int getTotalmoney() {
		return totalmoney;
	}

	public void setTotalmoney(int totalmoney) {
		this.totalmoney = totalmoney;
	}

	public int getTodaymoney() {
		return todaymoney;
	}

	public void setTodaymoney(int todaymoney) {
		this.todaymoney = todaymoney;
	}

	public int getIndividualcount() {
		return individualcount;
	}

	public void setIndividualcount(int individualcount) {
		this.individualcount = individualcount;
	}

	public int getCompanycount() {
		return companycount;
	}

	public void setCompanycount(int companycount) {
		this.companycount = companycount;
	}

	public int getGroupcount() {
		return groupcount;
	}

	public void setGroupcount(int groupcount) {
		this.groupcount = groupcount;
	}

}
