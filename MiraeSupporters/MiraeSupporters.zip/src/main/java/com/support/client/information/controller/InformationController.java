package com.support.client.information.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.support.client.information.service.InformationService;
import com.support.client.nursery.vo.NurseryVO;
import com.support.client.payment.vo.PaymentVO;

@Controller
@RequestMapping("/information")
public class InformationController {

	@Autowired
	private InformationService informationservice;

	// �ε��� ���������� �Ŀ� ���̵�� �Ѿ�� ���� ��Ʈ�ѷ�
	@RequestMapping("/support")
	public String support(Locale locale, Model model) {
		System.out.println("support");
		return "information/guide";
	}

	// ȸ�� ���� ������ �̵�
	@RequestMapping("/information")
	public String information(Locale locale, Model model) {
		System.out.println("information");
		return "information/information";
	}

	// ������ ������ �̵�
	@RequestMapping("/transparencyForm")
	public ModelAndView transparencyForm() {
		System.out.println("transparencyForm");
		PaymentVO mvo = new PaymentVO();
		NurseryVO nvo = new NurseryVO();
		ModelAndView mav = new ModelAndView();
		List<PaymentVO> payment = new ArrayList<>();
		payment = informationservice.transparencyForm();
		mvo = informationservice.selectamont();
		nvo = informationservice.selectnum();
		mvo.setI_num(nvo.getI_num());
		payment.set(0, mvo);
	      int nurserypayment = payment.get(0).getP_amountsum() / payment.get(0).getI_num();
	      mav.addObject("nurserypayment",nurserypayment);
		mav.addObject("transparencyForm", payment);
		mav.setViewName("information/transparency");
		return mav;
	}

}
