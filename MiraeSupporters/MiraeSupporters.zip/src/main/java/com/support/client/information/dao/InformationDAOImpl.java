package com.support.client.information.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import com.support.client.nursery.vo.NurseryVO;
import com.support.client.payment.vo.PaymentVO;

public class InformationDAOImpl implements InformationDAO{
	@Autowired
	private SqlSession session;
	
	public List<PaymentVO> transparencyForm(){
		return session.selectList("transparencyForm");
	}
	
	public PaymentVO selectamont() {
		return session.selectOne("selectamont");
	}
	
	public NurseryVO selectnum() {
		return session.selectOne("selectnum");
	}
}
