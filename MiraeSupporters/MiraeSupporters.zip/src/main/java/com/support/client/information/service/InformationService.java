package com.support.client.information.service;

import java.util.List;

import com.support.client.nursery.vo.NurseryVO;
import com.support.client.payment.vo.PaymentVO;

public interface InformationService {
	//������
	public List<PaymentVO> transparencyForm();
	
	//�ѱݾ� �հ�
	public PaymentVO selectamont();
	
	//������ �� 
	public NurseryVO selectnum();
}
