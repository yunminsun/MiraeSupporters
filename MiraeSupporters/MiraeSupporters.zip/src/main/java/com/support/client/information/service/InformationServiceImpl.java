package com.support.client.information.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.support.client.information.dao.InformationDAO;
import com.support.client.nursery.vo.NurseryVO;
import com.support.client.payment.vo.PaymentVO;

@Service
@Transactional
public class InformationServiceImpl implements InformationService {

	@Autowired
	private InformationDAO informationDAO;

	@Override
	public List<PaymentVO> transparencyForm() {
		List<PaymentVO> List = informationDAO.transparencyForm();
		return List;
	}
	
	@Override
	public PaymentVO selectamont() {
		PaymentVO pvo = informationDAO.selectamont();
		return pvo;
	}
	
	@Override
	public NurseryVO selectnum() {
		NurseryVO nvo = informationDAO.selectnum();
		return nvo;
	}
}
