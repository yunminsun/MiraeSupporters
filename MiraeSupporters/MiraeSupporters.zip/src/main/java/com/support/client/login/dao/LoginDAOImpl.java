package com.support.client.login.dao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import com.support.client.member.dao.MemberDAO;
import com.support.client.member.vo.MemberSecurity;
import com.support.client.member.vo.MemberVO;

public class LoginDAOImpl implements LoginDAO {

	@Autowired
	private SqlSession session;
	
	@Override
	public MemberVO loginSelect(MemberVO mvo) {
		// TODO Auto-generated method stub
		return session.selectOne("loginSelect",mvo);
	}

	@Override
	public int loginHistoryInsert(MemberVO mvo) {
		// TODO Auto-generated method stub
		return session.insert("loginHistoryInsert",mvo);
	}

	@Override
	public int loginHistoryUpdate(MemberVO mvo) {
		// TODO Auto-generated method stub
		return session.update("loginHistoryUpdate",mvo);
	}

	@Override
	public MemberVO loginHistorySelect(MemberVO mvo) {
		// TODO Auto-generated method stub
		return session.selectOne("loginHistorySelect",mvo);
	}

	@Override
	public MemberSecurity securitySelect(MemberVO mvo) {
		// TODO Auto-generated method stub
		return session.selectOne("securitySelect",mvo);
	}

	@Override
	public MemberVO findID(MemberVO mvo) {
		return (MemberVO)session.selectOne("findID",mvo);
	}

	@Override
	public MemberVO setPW(MemberVO mvo) {
		// TODO Auto-generated method stub
		return session.selectOne("setPW",mvo);
	}

	@Override
	public int updatePW(MemberVO mvo) {
		// TODO Auto-generated method stub
		return session.selectOne("updatePW",mvo);
	}

	@Override
	public int securityUpdate(MemberSecurity sec) {
		// TODO Auto-generated method stub
		return session.selectOne("securityUpdate",sec);
	}

	
}
