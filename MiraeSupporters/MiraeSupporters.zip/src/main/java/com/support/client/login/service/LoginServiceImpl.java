package com.support.client.login.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.support.client.login.dao.LoginDAO;
import com.support.client.member.dao.MemberDAO;
import com.support.client.member.util.OpenCrypt;
import com.support.client.member.util.Util;
import com.support.client.member.vo.MemberSecurity;
import com.support.client.member.vo.MemberVO;

@Service
@Transactional
public class LoginServiceImpl implements LoginService {
	Logger logger =Logger.getLogger(LoginService.class);
	
	@Autowired
	private LoginDAO loginDAO;
	
	@Autowired
	private MemberDAO memberDAO;
	
	
	//�α��� ��������Ȯ�� ��ȸ
	@Override
	public MemberVO loginSelect(MemberVO mvo) {
		
	      try {
	    	  mvo = loginDAO.loginSelect(mvo);
	      } catch (Exception e) {
	         e.printStackTrace();
	      }
	      return mvo;
	}

	//�Ϸ�� �α��� �� �ֱ�
	@Override
	public int loginHistoryInsert(MemberVO mvo) {
		// TODO Auto-generated method stub
		return 0;
	}

	//�Ϸ�� �α��ΰ� ����(��й�ȣ ����)
	@Override
	public int loginHistoryUpdate(MemberVO mvo) {
		// TODO Auto-generated method stub
		return 0;
	}

	//�Ϸ�� �α��ΰ� �˻�(�α��� ��)
	@Override
	public MemberVO loginHistorySelect(MemberVO mvo) {
		// TODO Auto-generated method stub
		return null;
	}
	//��ȣȭ
	
	@Override
	public MemberSecurity securitySelect(MemberVO mvo) {
		  MemberSecurity memberSecurity= new MemberSecurity();
	      try {
	    	  memberSecurity = loginDAO.securitySelect(mvo);
	      } catch (Exception e) {
	         e.printStackTrace();
	      }
	      return memberSecurity;
	}

	@Override
	public MemberVO findID(MemberVO mvo) {
		// TODO Auto-generated method stub
		MemberVO memberVO =new MemberVO();
		 try {
			 memberVO = loginDAO.findID(mvo);
			 System.out.println("service : "+memberVO);
	      } catch (Exception e) {
	         e.printStackTrace();
	      }
	      return memberVO;
	}

	@Override
	public MemberVO setPW(MemberVO mvo) {
		// TODO Auto-generated method stub
		MemberVO memberVO =new MemberVO();
		 try {
			 memberVO = loginDAO.setPW(mvo);
			 System.out.println("service : "+memberVO);
	      } catch (Exception e) {
	         e.printStackTrace();
	      }
	      return memberVO;
	}

	@Override
	public int updatePW(MemberVO mvo) {
		int sCode = 2;
		int result = 0;
		/*if (memberDAO.memberSearchID(mvo) != null) {
			return result;
		} else {*/
		try {
			MemberSecurity sec = new MemberSecurity();
			sec.setUserId(mvo.getS_id());
			sec.setSalt(Util.getRandomString());
			sCode = loginDAO.securityUpdate(sec);
			if (sCode == 1) {
				mvo.setS_pw(new String(OpenCrypt.getSHA256(mvo.getS_pw(), sec.getSalt())));
			result = loginDAO.updatePW(mvo);
			return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
		/*}*/
	}


	
	
}
