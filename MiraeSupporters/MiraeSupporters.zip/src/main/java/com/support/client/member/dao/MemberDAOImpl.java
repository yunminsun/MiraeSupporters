package com.support.client.member.dao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import com.support.client.member.vo.MemberSecurity;
import com.support.client.member.vo.MemberVO;

public class MemberDAOImpl implements MemberDAO {

	@Autowired
	private SqlSession session;

	@Override
	public int memberInsert(MemberVO memberVO) {
		return session.insert("memberInsert", memberVO);
	}

	@Override
	public int memberUpdate(MemberVO memberVO) {
		return session.update("memberUpdate", memberVO);
	}

	
	@Override
	public MemberVO memberDetail(MemberVO memberVO) {
		
		return session.selectOne("memberDetail",memberVO);
	}


	@Override
	public MemberVO memberSearchNum(MemberVO memberVO) {
		return session.selectOne("memberSearchNum", memberVO);
	}

	@Override
	public MemberVO memberSearchID(MemberVO memberVO) {
		return session.selectOne("memberSearchID", memberVO);
	}

	@Override
	public int securityInsert(MemberSecurity set) {
		return session.insert("securityInsert", set);
	}

	@Override
	public MemberVO memberidcofirm(MemberVO memberVO) {
		
		return session.selectOne("memberidcofirm", memberVO);
	}

	@Override
	public MemberVO memberAsk(MemberVO memberVO) {
		return session.selectOne("memberAsk", memberVO);
	}

	
}
