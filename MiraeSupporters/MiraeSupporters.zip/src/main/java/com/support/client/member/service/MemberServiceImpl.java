package com.support.client.member.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.support.client.member.dao.MemberDAO;
import com.support.client.member.util.OpenCrypt;
import com.support.client.member.util.Util;
import com.support.client.member.vo.MemberSecurity;
import com.support.client.member.vo.MemberVO;

@Service
@Transactional
public class MemberServiceImpl implements MemberService {
	Logger logger = Logger.getLogger(MemberService.class);

	@Autowired
	private MemberDAO memberDAO;

	// �Ŀ��� ���
	@Override
	   public int memberInsert(MemberVO memberVO) {
	      int result = 0;
	      try {
	         result = memberDAO.memberInsert(memberVO);
	      } catch (Exception e) {
	         e.printStackTrace();
	         result = 0;
	      }
	      return result;
	   }

	// ȸ������ (ID,PW)
	@Override
	public int memberUpdate(MemberVO memberVO) {
		int sCode = 2;
		int result = 0;
		if (memberDAO.memberSearchID(memberVO) != null) {
			return result;
		} else {
		try {
			MemberSecurity sec = new MemberSecurity();
			sec.setUserId(memberVO.getS_id());
			sec.setSalt(Util.getRandomString());
			sCode = memberDAO.securityInsert(sec);

			if (sCode == 1) {
				memberVO.setS_pw(new String(OpenCrypt.getSHA256(memberVO.getS_pw(), sec.getSalt())));
			result = memberDAO.memberUpdate(memberVO);
			return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
		}
	}
	// �Ŀ���ȸ
		@Override
		public MemberVO memberDetail(MemberVO memberVO) {
			MemberVO join = null;
			try {
				join = memberDAO.memberDetail(memberVO);
			} catch (Exception e) {
				e.printStackTrace();
				join = null;
			}
			return join;
		}

	

	@Override
	public MemberVO memberSearchNum(MemberVO memberVO) {
		MemberVO result = null;
		try {
			result = memberDAO.memberSearchNum(memberVO);
		} catch (Exception e) {
			e.printStackTrace();
			result = null;
		}
		return result;
	}

	@Override
	public MemberVO memberSearchID(MemberVO memberVO) {
		MemberVO result = null;
		try {
			result = memberDAO.memberSearchID(memberVO);
		} catch (Exception e) {
			e.printStackTrace();
			result = null;
		}
		return result;
	}

	@Override
	public MemberVO memberidcofirm(MemberVO memberVO) {
		MemberVO result = null;
		try {
			result = memberDAO.memberidcofirm(memberVO);
		} catch (Exception e) {
			e.printStackTrace();
			result = null;
		}
		return result;
	}

	@Override
	public MemberVO memberAsk(MemberVO memberVO) {
		MemberVO join = null;
		try {
			join = memberDAO.memberAsk(memberVO);
		} catch (Exception e) {
			e.printStackTrace();
			join = null;
		}
		return join;
	}

}
