package com.support.client.mypage.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.support.client.member.vo.MemberSecurity;
import com.support.client.member.vo.MemberVO;
import com.support.client.mypage.service.MypageService;
import com.support.client.payment.vo.PaymentVO;
import com.support.client.question.vo.QuestionVO;

@Controller
@RequestMapping("/mypage")
public class MypageController {

	@Autowired
	private MypageService mypageservice;

	// ���� ���� s_num ���� �ϱ� ���� int ���� �� ���� ����
	// ���������� ȸ�� Ȯ��
	@RequestMapping("/mypagedetail")
	public ModelAndView MypageDetail(HttpSession session) {
		ModelAndView mav = new ModelAndView();
		System.out.println("mypagedetail");
		if(session.getAttribute("s_num") == null) {
			mav.setViewName("login/login");
		}else {
			int s_num = (int) session.getAttribute("s_num");
			MemberVO mVO = mypageservice.mypagedetail(s_num);
			mav.addObject("mypage", mVO);
			mav.setViewName("mypage/mypagedetail");
		}
		return mav;
	}

	// �������� ����
	// redirect �� jsp�� �Ѿ�� �ʰ� �ٽ� ��Ʈ�ѷ��� �����ϴ°�
	@RequestMapping("/mypageupdate")
	public ModelAndView MypageUpdate(HttpSession session, MemberVO mvo) {
		System.out.println("mypageupdate");
		ModelAndView mav = new ModelAndView();
		int s_num = (int) session.getAttribute("s_num");
		mvo.setS_num(s_num);
		int count = mypageservice.mypageupdate(mvo);
		System.out.println(count);
		mav.addObject("mypage", count);
		mav.setViewName("mypage/mypageupdate");
		return mav;
	}

	// ��й�ȣ ���� �� ���ο� â���� ����
	@RequestMapping("/mypagepwform")
	public String MypagpwForm(HttpSession session) {
		System.out.println("mypagepwform");
		return "mypage/pwform/mypagepwForm";
	}

	// ���� ��й�ȣ �� ���̵� �� ��������
	@ResponseBody
	@RequestMapping("/passwordselect")
	public MemberVO mypagepwForm(HttpSession session, MemberVO memberVO) {
		System.out.println("passwordselect");
		MemberVO mvo = new MemberVO();
		MemberSecurity svo = new MemberSecurity();
		String password = "";
		int s_num = (int) session.getAttribute("s_num");
		memberVO.setS_num(s_num);

		password = memberVO.getS_pw();

		// ���̵� ��й�ȣ ã��
		mvo = mypageservice.passwordselect(memberVO);

		// ��ȣ�� �ڵ� ã��
		svo = mypageservice.securityselect(mvo.getS_id());
		// �Է��� ��й�ȣ ��ȣȭ
		password = mypageservice.securitypw(password, svo);
		// �Է��� ��й�ȣ�� ���� ��й�ȣ ��
		if (password.equals(mvo.getS_pw())) {
			mvo.setS_id("");
		}
		return mvo;
	}

	// ��й�ȣ ����
	@RequestMapping("/passwordupdate")
	public int passwordupdate(MemberVO memberVO) {
		System.out.println("passwordupdate");
		int result = 0;
		MemberSecurity svo = new MemberSecurity();
		svo = mypageservice.securityselect(memberVO.getS_id());

		result = mypageservice.passwordupdate(memberVO, svo);
		return result;
	}

	// �Ŀ� ���� �˻� ������ �̵�
	@RequestMapping("/mypagesponsor")
	public ModelAndView sponsorForm(HttpSession session) {
		System.out.println("sponsorForm");
		ModelAndView mav = new ModelAndView();
		if(session.getAttribute("s_num") == null) {
			mav.setViewName("login/login");
		}else {
		int s_num = (int) session.getAttribute("s_num");
		List<PaymentVO> paymentList = mypageservice.mypagesponsor(s_num);
		mav.addObject("payment", paymentList);
		mav.setViewName("mypage/mypagesponsorForm");}
		return mav;
	}

	// �Ŀ� ���� �˻�
	@ResponseBody
	@RequestMapping("/paymentsearch")
	public ModelAndView paymentsearch(HttpSession session, PaymentVO paymentVO) {
		System.out.println("paymentsearch");
		ModelAndView mav = new ModelAndView();
		int s_num = (int) session.getAttribute("s_num");
		paymentVO.setS_num(s_num);
		List<PaymentVO> paymentList = mypageservice.paymentsearch(paymentVO);
		mav.addObject("payment", paymentList);
		mav.setViewName("mypage/mypagesponsorForm");
		return mav;
	}

	// �� ������ ���� �̵�
	@RequestMapping("/myquestion")
	public ModelAndView myquestion(HttpSession session, QuestionVO questionVO) {
		System.out.println("myquestion");
		ModelAndView mav = new ModelAndView(); 
		if(session.getAttribute("s_num") == null) {
			mav.setViewName("login/login");
		}else {
		int s_num = (int) session.getAttribute("s_num");
		questionVO.setS_num(s_num);
		List<QuestionVO> questionList = mypageservice.myquestion(questionVO);
		mav.addObject("myquestion", questionList);
		mav.setViewName("mypage/myquestion");}
		return mav;
	}

	// �Ŀ� ������ �� �̵�
	@RequestMapping("/certificate")
	public ModelAndView certificate(HttpSession session) {
		System.out.println("certificate");
		ModelAndView mav = new ModelAndView();
		PaymentVO pvo = new PaymentVO();
		if (session.getAttribute("s_num") == null) {
			mav.setViewName("login/login");
		} else {
			pvo.setS_num((int) session.getAttribute("s_num"));
			pvo = mypageservice.certificate(pvo);
			mav.addObject("certificate", pvo);
			mav.setViewName("mypage/certificate");
		}
		return mav;
	}



}
