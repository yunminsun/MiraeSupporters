package com.support.client.notice.controller;



import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.support.client.common.page.Paging;
import com.support.client.member.util.Util;
import com.support.client.notice.service.NoticeService;
import com.support.client.notice.vo.NoticeVO;

/**
 * Handles requests for the application home page.
 */
@Controller
@RequestMapping(value = "/notice")
public class NoticeController {

	Logger logger = Logger.getLogger(NoticeController.class);

	@Autowired
	private NoticeService noticeService;
	
	// �۸�� ����
	@RequestMapping(value = "/noticeList", method=RequestMethod.GET)
	public String notice(@ModelAttribute NoticeVO nvo, Model model) {
		logger.info("NoticeList �������� ��� ȣ�⼺��123");
		
		//������ ����
		Paging.setPage(nvo);
		
		//��ü ���ڵ� �� ����
		int total =noticeService.noticeListCnt(nvo);
		logger.info("total="+total);
		
		//�۹�ȣ �缳��
		int count =total-(Util.nvl(nvo.getPage())-1)*Util.nvl(nvo.getPageSize());
		logger.info("count="+count);
		
		List<NoticeVO> noticeList = noticeService.noticeList(nvo);
		model.addAttribute("noticeList",noticeList);
		model.addAttribute("count",count);
		model.addAttribute("total",total);
		model.addAttribute("data",nvo);
		
		return "notice/noticeList";
	}
	
	//�E �� ���� ����, �Խñ� ��ȸ�� ���� ó��
	@RequestMapping(value="/notice_detail")
	public String noticedetail(@ModelAttribute NoticeVO nvo, Model model) {
		logger.info("noticeDetail ȣ�⼺��");
		logger.info("n_num ="+nvo.getN_num());
		
		//��ȸ�� ���� ó���޼ҵ�
		//noticeService.updateViewsUP(n_views,session);
		//�信 ���� �� ������
		//mav.addObject("vo",noticeService.read(n_views));
		//return mav;
		
		
		NoticeVO detail=new NoticeVO();
		detail=noticeService.noticeDetail(nvo);
		
		if(detail!=null&&(!detail.equals(""))) {
			detail.setN_content(detail.getN_content().toString().replaceAll("\n", "<br>"));
		}
		model.addAttribute("detail",detail);
		return "notice/notice_detail";
	}
	
	
	

	
}
