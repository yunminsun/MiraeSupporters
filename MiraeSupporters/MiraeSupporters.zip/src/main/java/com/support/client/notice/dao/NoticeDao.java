package com.support.client.notice.dao;

import java.util.List;

import com.support.client.notice.vo.NoticeVO;

public interface NoticeDao {
	public List<NoticeVO> noticeList(NoticeVO nvo);
	public NoticeVO noticeDetail(NoticeVO nvo);
	public int noticeListCnt(NoticeVO nvo);
	public int noticeViewsUP(NoticeVO nvo);

/*	public void updateViewsUP(int n_view)throws Exception;*/
	
}
