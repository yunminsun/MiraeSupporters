package com.support.client.notice.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.support.client.notice.vo.NoticeVO;

@Repository
public class NoticeDaoImpl implements NoticeDao {

	@Autowired
	private SqlSession session;

	// �������� ��ϱ���
	@Override
	public List<NoticeVO> noticeList(NoticeVO nvo) {
		// TODO Auto-generated method stub
		return session.selectList("noticeList",nvo);
	}
	
	@Override
	public int noticeListCnt(NoticeVO nvo) {
		// TODO Auto-generated method stub
		return session.selectOne("noticeListCnt");
	}

	// �������� �󼼺��ⱸ��
	@Override
	public NoticeVO noticeDetail(NoticeVO nvo) {
		// TODO Auto-generated method stub
		return session.selectOne("noticeDetail",nvo);
	}

	@Override
	public int noticeViewsUP(NoticeVO nvo) {
		// TODO Auto-generated method stub
		return session.update("noticeViewsUP",nvo);
	}

/*	//��ȸ�� ����
	@Override
	public void updateViewsUP(int n_view) throws Exception {
		// TODO Auto-generated method stb
		session.update("notice.updateViewsUP",n_view);
	}
*/
/*	// ���̵�Ȯ�α���
	@Override
	public int idConfirm(NoticeVO nvo) {
		// TODO Auto-generated method stub
		return 0;
	}*/

	// ��й�ȣȮ�α���
	
}
