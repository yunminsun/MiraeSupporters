package com.support.client.notice.service;

import java.util.List;

import javax.servlet.http.HttpSession;

import com.support.client.notice.vo.NoticeVO;

public interface NoticeService {
public List<NoticeVO> noticeList(NoticeVO nvo);
public NoticeVO noticeDetail(NoticeVO nvo);
public int noticeListCnt(NoticeVO nvo);
/*public void updateViewsUP(int n_view,HttpSession session) throws Exception;*/

}
