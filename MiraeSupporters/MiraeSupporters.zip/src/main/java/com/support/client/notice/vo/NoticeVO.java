package com.support.client.notice.vo;

import org.springframework.web.multipart.MultipartFile;

import com.support.client.common.vo.CommonVO;

public class NoticeVO extends CommonVO{
private int n_num =0; //�۹�ȣ
private String n_title=""; //�� ����
private String n_date=""; //�ۼ���
private String n_content=""; //�� ����
private int n_views=0; //��ȸ��
private int a_num=0;
private String a_name=""; //������ �̸�


//���� ���ε带 ���� �Ӽ�
private MultipartFile file; //÷������
private String b_file=""; //���� ������ ������ ���ϸ�

//��� ���� ���� �Ӽ�
private int r_cnt=0;


public String getA_name() {
	return a_name;
}
public void setA_name(String a_name) {
	this.a_name = a_name;
}
public MultipartFile getFile() {
	return file;
}
public void setFile(MultipartFile file) {
	this.file = file;
}
public String getB_file() {
	return b_file;
}
public void setB_file(String b_file) {
	this.b_file = b_file;
}
public int getR_cnt() {
	return r_cnt;
}
public void setR_cnt(int r_cnt) {
	this.r_cnt = r_cnt;
}
public int getA_num() {
	return a_num;
}
public void setA_num(int a_num) {
	this.a_num = a_num;
}
public int getN_num() {
	return n_num;
}
public void setN_num(int n_num) {
	this.n_num = n_num;
}
public String getN_title() {
	return n_title;
}
public void setN_title(String n_title) {
	this.n_title = n_title;
}
public String getN_date() {
	return n_date;
}
public void setN_date(String n_date) {
	this.n_date = n_date;
}
public String getN_content() {
	return n_content;
}
public void setN_content(String n_content) {
	this.n_content = n_content;
}
public int getN_views() {
	return n_views;
}
public void setN_views(int n_views) {
	this.n_views = n_views;
}


}
