package com.support.client.nursery.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.support.client.nursery.service.NurseryService;
import com.support.client.nursery.vo.NurseryVO;

@Controller
@RequestMapping("/nursery")
public class NurseryController {

	@Autowired
	private NurseryService nurseryService;
	
	//������ ����Ʈ
	@RequestMapping("/nurseryList.do")
	public ModelAndView nurseryList() {
		ModelAndView mav = new ModelAndView();
		List<NurseryVO> nurseryList = nurseryService.nurseryList();
		mav.addObject("nurseryList", nurseryList);
		mav.setViewName("information/nursery");

		return mav;
	}

	//������ �̹��� Ŭ���� ����Ʈ �ڽ� ����Ʈ
	@ResponseBody
	@RequestMapping("/nurserySearch")
	public NurseryVO nurserySearch(NurseryVO nurseryVO) {
		NurseryVO nurserySearch = nurseryService.nurserySearch(nurseryVO);
		
		return nurserySearch;
	}

}
