package com.support.client.nursery.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.support.client.nursery.vo.NurseryVO;

@Repository
public class NurseryDAOImpl implements NurseryDAO {

	@Autowired
	private SqlSessionTemplate session;
	//������ ����Ʈ
	@Override
	public List<NurseryVO> nurseryList() {
		return session.selectList("nurseryList");
	}
	//������ �̹��� Ŭ���� �ش� ������ ����
	@Override
	public NurseryVO nurserySearch(NurseryVO nurseryVO) {
		System.out.println("nurserySearch");
		return session.selectOne("nurserySearch", nurseryVO);
	}

}
