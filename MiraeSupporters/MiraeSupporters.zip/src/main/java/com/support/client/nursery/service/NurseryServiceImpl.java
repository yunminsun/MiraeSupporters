package com.support.client.nursery.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.support.client.nursery.dao.NurseryDAO;
import com.support.client.nursery.vo.NurseryVO;

@Service
@Transactional
public class NurseryServiceImpl implements NurseryService {
	Logger logger = Logger.getLogger(NurseryService.class);

	@Autowired
	private NurseryDAO nurseryDAO;
	//������ ����Ʈ
	@Override
	public NurseryVO nurserySearch(NurseryVO nurseryVO) {
		NurseryVO ivo = nurseryDAO.nurserySearch(nurseryVO);
		return ivo;
	}
	//������ �̹��� Ŭ���� �ش� ������ ����
	@Override
	public List<NurseryVO> nurseryList() {
		List<NurseryVO> nurseryList = nurseryDAO.nurseryList();
		return nurseryList;
	}

}
