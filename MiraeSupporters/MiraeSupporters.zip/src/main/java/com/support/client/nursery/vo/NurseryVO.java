package com.support.client.nursery.vo;

public class NurseryVO {

	private int i_num = 0; //������ ��ȣ
	private String i_name = ""; //������ �̸�
	private String i_officenum = ""; //�繫�� ��ȣ 
	private String i_content = ""; //�Ұ�
	private String i_owner = ""; //��ǥ��
	private String i_facilitiestel = ""; //��ǥ��ȣ
	private int i_max = 0; //������ ����
	private int i_children = 0; // ������ �̿�Ƶ�
	private String i_addr = ""; //������ �ּ�
	private String i_bank = ""; //������ ����
	private String i_account = ""; //������ ���¹�ȣ
	private String i_file_paramorma = ""; //������ ����
	private String i_file_addr = ""; //������ �ּ�
	private String i_file_inside_a = ""; //������ �ǳ����� a
	private String i_file_inside_b = "";//������ �ǳ����� b
	private String i_file_inside_c = "";//������ �ǳ����� c

	public int getI_num() {
		return i_num;
	}

	public void setI_num(int i_num) {
		this.i_num = i_num;
	}

	public String getI_name() {
		return i_name;
	}

	public void setI_name(String i_name) {
		this.i_name = i_name;
	}

	public String getI_officenum() {
		return i_officenum;
	}

	public void setI_officenum(String i_officenum) {
		this.i_officenum = i_officenum;
	}

	public String getI_content() {
		return i_content;
	}

	public void setI_content(String i_content) {
		this.i_content = i_content;
	}

	public String getI_owner() {
		return i_owner;
	}

	public void setI_owner(String i_owner) {
		this.i_owner = i_owner;
	}

	public String getI_facilitiestel() {
		return i_facilitiestel;
	}

	public void setI_facilitiestel(String i_facilitiestel) {
		this.i_facilitiestel = i_facilitiestel;
	}

	public int getI_max() {
		return i_max;
	}

	public void setI_max(int i_max) {
		this.i_max = i_max;
	}

	public int getI_children() {
		return i_children;
	}

	public void setI_children(int i_children) {
		this.i_children = i_children;
	}

	public String getI_addr() {
		return i_addr;
	}

	public void setI_addr(String i_addr) {
		this.i_addr = i_addr;
	}

	public String getI_bank() {
		return i_bank;
	}

	public void setI_bank(String i_bank) {
		this.i_bank = i_bank;
	}

	public String getI_account() {
		return i_account;
	}

	public void setI_account(String i_account) {
		this.i_account = i_account;
	}

	public String getI_file_paramorma() {
		return i_file_paramorma;
	}

	public void setI_file_paramorma(String i_file_paramorma) {
		this.i_file_paramorma = i_file_paramorma;
	}

	public String getI_file_addr() {
		return i_file_addr;
	}

	public void setI_file_addr(String i_file_addr) {
		this.i_file_addr = i_file_addr;
	}

	public String getI_file_inside_a() {
		return i_file_inside_a;
	}

	public void setI_file_inside_a(String i_file_inside_a) {
		this.i_file_inside_a = i_file_inside_a;
	}

	public String getI_file_inside_b() {
		return i_file_inside_b;
	}

	public void setI_file_inside_b(String i_file_inside_b) {
		this.i_file_inside_b = i_file_inside_b;
	}

	public String getI_file_inside_c() {
		return i_file_inside_c;
	}

	public void setI_file_inside_c(String i_file_inside_c) {
		this.i_file_inside_c = i_file_inside_c;
	}

}
