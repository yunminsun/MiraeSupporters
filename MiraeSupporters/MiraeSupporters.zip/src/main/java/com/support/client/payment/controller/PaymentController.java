package com.support.client.payment.controller;


import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.support.client.member.service.MemberService;
import com.support.client.member.vo.MemberVO;
import com.support.client.payment.service.PaymentService;
import com.support.client.payment.vo.PaymentVO;
@Controller
@RequestMapping("/payment")
public class PaymentController {
	private static final Logger logger = LoggerFactory.getLogger(PaymentController.class);
	@Autowired
	private PaymentService paymentService;
	@Autowired
	private MemberService memberService;
	/***************************
	 * �Ŀ����� �� > �Ŀ� �Ϸ� ������
	 * �Ϸ�� �Ŀ�����Ʈ�� ������ �Ѿ.
	 ***************************/
	@RequestMapping(value = "/paymentInsert" , method = RequestMethod.POST)
	public ModelAndView paymentInsert(@ModelAttribute PaymentVO paymentVO) {
		logger.info("�Ŀ��� ����");
		ModelAndView mav = new ModelAndView();
		int result = 0;
		List<PaymentVO> payList = null;
		MemberVO mVo = new MemberVO();
		mVo = memberService.memberSearchNum(paymentVO);
		result = paymentService.paymentInsert(paymentVO);
		payList = paymentService.paymentSearch(paymentVO);
		if (result == 1) {
			mav.addObject("mVo", mVo);
			mav.setViewName("support/Application_com");
			mav.addObject("payList",payList);
		}else {
			System.out.println("��Ͻ��� : controller paymentInsert");
		}
		
		return mav;
		
	}
}
