package com.support.client.payment.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import com.support.client.payment.vo.PaymentVO;

public class PaymentDAOImpl implements PaymentDAO{
	@Autowired
	private SqlSession session;
	@Override
	public int paymentInsert(PaymentVO paymentVO) {
		return session.insert("paymentInsert", paymentVO);
	}
	@Override
	public List<PaymentVO> paymentSearch(PaymentVO paymentVO) {
		
		return session.selectList("paymentSearch", paymentVO);
	}
	

}
