package com.support.client.payment.vo;

import java.sql.Date;

import com.support.client.member.vo.MemberVO;

public class PaymentVO extends MemberVO{
	
	private int p_num; //�Ŀ���ȣ
	private int p_amount; //�ݾ�
	private Date p_date = null; //��¥
	private String p_method=""; // ��������
	private String p_businessnum=""; // ����ڵ�Ϲ�ȣ
	private String p_relationship=""; // ����
	private String p_bank=""; //����
	private String p_category=""; // �������
	private String p_account=""; // ��������
	private String p_accountholder=""; //�����ָ�
	private int s_num; // �Ŀ��ι�ȣ
	private int i_num; // ������ ��(���������� ���)
	private Date dateA = null; // ��¥ �˻� �� ��� �� ������ �ּ� ��¥
	private Date dateB = null; // ��¥ �˻� �� ��� �� ������ �ִ� ��¥
	private int p_sum; //�����ѱݾ�(������ ���)
	private int p_amountsum; //�ѱݾ�
	
	public int getI_num() {
		return i_num;
	}
	public void setI_num(int i_num) {
		this.i_num = i_num;
	}
	public Date getDateA() {
		return dateA;
	}
	public void setDateA(Date dateA) {
		this.dateA = dateA;
	}
	public Date getDateB() {
		return dateB;
	}
	public void setDateB(Date dateB) {
		this.dateB = dateB;
	}
	public int getP_sum() {
		return p_sum;
	}
	public void setP_sum(int p_sum) {
		this.p_sum = p_sum;
	}
	public int getP_amountsum() {
		return p_amountsum;
	}
	public void setP_amountsum(int p_amountsum) {
		this.p_amountsum = p_amountsum;
	}
	public PaymentVO() {
		super();
	}
	public int getP_num() {
		
		return p_num;
	}
	public void setP_num(int p_num) {
		
		this.p_num = p_num;
	}
	public int getP_amount() {
		return p_amount;	
	}
	public void setP_amount(int p_amount) {
		this.p_amount = p_amount;
	}
	public Date getP_date() {
		return p_date;
	}
	public void setP_date(Date p_date) {
		this.p_date = p_date;
	}
	public String getP_method() {
		return p_method;
	}
	public void setP_method(String p_method) {
		this.p_method = p_method;
	}
	public String getP_businessnum() {
		return p_businessnum;
	}
	public void setP_businessnum(String p_businessnum) {
		this.p_businessnum = p_businessnum;
	}
	public String getP_relationship() {
		return p_relationship;
	}
	public void setP_relationship(String p_relationship) {
		this.p_relationship = p_relationship;
	}
	public String getP_bank() {
		return p_bank;
	}
	public void setP_bank(String p_bank) {
		this.p_bank = p_bank;
	}
	public String getP_category() {
		return p_category;
	}
	public void setP_category(String p_category) {
		this.p_category = p_category;
	}
	public String getP_account() {
		return p_account;
	}
	public void setP_account(String p_account) {
		this.p_account = p_account;
	}
	public String getP_accountholder() {
		return p_accountholder;
	}
	public void setP_accountholder(String p_accountholder) {
		this.p_accountholder = p_accountholder;
	}
	public int getS_num() {
		return s_num;
	}
	public void setS_num(int s_num) {
		this.s_num = s_num;
	}
	
	
	
}
