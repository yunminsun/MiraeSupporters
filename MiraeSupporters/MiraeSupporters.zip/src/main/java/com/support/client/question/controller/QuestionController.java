package com.support.client.question.controller;

import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.support.client.common.page.Paging;
import com.support.client.member.dao.MemberDAO;
import com.support.client.member.util.Util;
import com.support.client.notice.vo.NoticeVO;
import com.support.client.question.dao.QuestionDao;
import com.support.client.question.service.QuestionService;
import com.support.client.question.vo.QuestionVO;

@Controller
@RequestMapping(value="/question")
public class QuestionController {
Logger logger=Logger.getLogger(QuestionController.class);

@Autowired
private QuestionService questionService;


/*�۸�� �����ϱ�*/
@RequestMapping(value="/questionList", method=RequestMethod.GET)
public String questionList(@ModelAttribute QuestionVO qvo,Model model) {
	logger.info("qnaList ȣ�� ����");
	
	//������ ����
	Paging.setPage(qvo);
	
	//��ü���ڵ� �� ����
	int total =questionService.questionListCnt(qvo);
	logger.info("total="+total);
	
	//�� ��ȣ �缳��
	int count=total-(Util.nvl(qvo.getPage())-1)*Util.nvl(qvo.getPageSize());
	logger.info("count="+count);
	
	List<QuestionVO> questionList =questionService.questionList(qvo); 
	model.addAttribute("questionList",questionList);
	model.addAttribute("count",count);
	model.addAttribute("total",total);
	model.addAttribute("data",qvo);
	
	return "question/questionList";
	
}

/*�۾��� �� ����ϱ�*/
@RequestMapping(value="/question_write")
public String question_write() {
	logger.info("wirteForm ȣ�� ����");
	
	//����
	return "question/question_write";
}

/*�۾��� �����ϱ�*/
@RequestMapping(value="/questionInsert")
public String questionInsert(@ModelAttribute QuestionVO qvo, Model model, HttpServletRequest request)throws IllegalStateException,IOException {
	logger.info("questionInsert ȣ�� ����");
	
	int result=0;
	String url="";
	System.out.println(qvo.getQ_title()+": qc");
	result=questionService.questionInsert(qvo);
	if(result==1) {
		url="/question/questionList.do";
		return "redirect:"+url;
	}else {
		model.addAttribute("code",1);
		url="question/question_write";
	}
	return url;
}
/*�� �󼼺��� ����*/
@RequestMapping(value="/question_detail")
public String question_detail(@ModelAttribute QuestionVO qvo, Model model) {
	logger.info("question ȣ�� ����");
	logger.info("q_num=" +qvo.getQ_num());
	
	//�Է��� vo �о����
	QuestionVO detail=new QuestionVO();
	detail=questionService.questionDetail(qvo);
	
	if(detail!=null&&(!detail.equals(""))) {
		detail.setQ_content(detail.getQ_content().toString().replaceAll("\n", "<br>"));
	}
	model.addAttribute("detail",detail);
	return "question/question_detail";
	
}
/*�ۼ����� ����ϱ�*/
@RequestMapping(value="/question_update")
public String question_update(@ModelAttribute QuestionVO qvo, Model model) {
	logger.info("questionUpdate �� ȣ�⼺��");
	
	QuestionVO updateData =new QuestionVO();
	updateData=questionService.questionDetail(qvo);
	System.out.println("con : "+updateData.getQ_num());
	
	model.addAttribute("updateData",updateData);
	return "question/question_update";
}

/*�� ���� �����ϱ�*/
@RequestMapping(value="/questionUpdate")
public String questionUpdate(@ModelAttribute QuestionVO qvo,HttpServletRequest request) {
	logger.info("questionUpdate ȣ�� ����");
	
	int result=0;
	String url="";
	System.out.println("con : "+qvo.getQ_num());
	
	result=questionService.questionUpdate(qvo);
	if(result==1) {
		//url="/questionList"//������ ������� �̵�
		//�Ʒ� url�� ���� �� ���������� �̵�
		url="/question/question_detail?q_num="+qvo.getQ_num();
	}else {
		url="/question/question_update?q_num="+qvo.getQ_num();
	}
	return "redirect:"+url;
}



}
