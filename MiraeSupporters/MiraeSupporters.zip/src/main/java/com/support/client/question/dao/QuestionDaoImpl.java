package com.support.client.question.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.support.client.question.vo.QuestionVO;

@Repository
public class QuestionDaoImpl implements QuestionDao {

	@Autowired
	private SqlSession session;
	
	
	
	//�۸�ϱ���
		@Override
		public List<QuestionVO> questionList(QuestionVO qvo) {
		
		return session.selectList("questionList",qvo);
		}
		
		//��ü ���ڵ� �Ǽ� ����
		@Override
		public int questionListCnt(QuestionVO qvo) {
			// TODO Auto-generated method stub
			return session.selectOne("questionListCnt");
		}
		
		//���Է� �����ϱ�
		@Override
		public int questionInsert(QuestionVO qvo) {
			return session.insert("questionInsert",qvo);
		}

		//�ۻ� ����
		@Override
		public QuestionVO questionDetail(QuestionVO qvo) {
			return session.selectOne("question_detail",qvo);
		}

		//�� ��������
		@Override
		public int questionUpdate(QuestionVO qvo) {
			return session.update("questionUpdate",qvo);
		}

		@Override
		public int questionViewsUP(QuestionVO qvo) {
			// TODO Auto-generated method stub
			return session.update("questionViewsUP",qvo);
		}

}
