


package com.support.client.question.service;

import java.util.List;

import com.support.client.question.vo.QuestionVO;

public interface QuestionService {
public List<QuestionVO> questionList(QuestionVO qvo);
public int questionInsert(QuestionVO qvo);
public QuestionVO questionDetail(QuestionVO qvo);
public int questionUpdate (QuestionVO qvo);
public int questionListCnt(QuestionVO qvo);

}
