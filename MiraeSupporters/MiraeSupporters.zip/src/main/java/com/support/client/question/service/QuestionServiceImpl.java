package com.support.client.question.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.support.client.question.dao.QuestionDao;
import com.support.client.question.vo.QuestionVO;

@Service
@Transactional
public class QuestionServiceImpl implements QuestionService {
	Logger logger =Logger.getLogger(QuestionServiceImpl.class);
	
	@Autowired
	private QuestionDao questionDao;
	
	
	//�۸�ϱ���
	@Override
	public List<QuestionVO> questionList(QuestionVO qvo) {
	List<QuestionVO> myList=null;
	
	/*//���Ŀ� ���� �⺻�� ����
	if(qvo.getOrder_by()==null) {
		qvo.setOrder_by("q_num");
	}
	if(qvo.getOrder_sc()==null) {
		qvo.setOrder_sc("DESC");
	}*/
	
	myList=questionDao.questionList(qvo);
	System.out.println(myList);
	return myList;
	}
	
	//��ü ���ڵ� �� ����
	@Override
	public int questionListCnt(QuestionVO qvo) {
		return questionDao.questionListCnt(qvo);
	}
	
	//���Է� �����ϱ�
	@Override
	public int questionInsert(QuestionVO qvo) {
		// TODO Auto-generated method stub
		int result=0;
		try {
			result=questionDao.questionInsert(qvo);
		}catch (Exception e) {
			e.printStackTrace();
			result=0;
		}
		
		return result;
	}

	//�ۻ� ����
	@Override
	public QuestionVO questionDetail(QuestionVO qvo) {

		// TODO Auto-generated method stub
		QuestionVO detail = null;
		detail = questionDao.questionDetail(qvo);
		// ��ȸ������
		detail.setQ_views(detail.getQ_views() + 1);
		questionDao.questionViewsUP(detail);
		return detail;
	}

	//�� ��������
	@Override
	public int questionUpdate(QuestionVO qvo) {
		int result=0;
		try {
			result=questionDao.questionUpdate(qvo);
		}catch (Exception e) {
			e.printStackTrace();
			result=0;
		}
		return result;
	}




}
