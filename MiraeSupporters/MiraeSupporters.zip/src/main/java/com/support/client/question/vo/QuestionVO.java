package com.support.client.question.vo;

import org.springframework.web.multipart.MultipartFile;

import com.support.client.common.vo.CommonVO;

public class QuestionVO extends CommonVO { 
private int q_num=0; //���� ��ȣ
private String q_title=""; //��������
private String q_name=""; //������
private String q_date=""; //������¥
private int q_views=0; //���� ��ȸ��
private String q_content=""; //���� ����
private int s_num; //�Ŀ��� ��ȣ

//��� ���� ���� �Ӽ�
private int r_cnt=0;

public int getR_cnt() {
	return r_cnt;
}
public void setR_cnt(int r_cnt) {
	this.r_cnt = r_cnt;
}
public int getQ_num() {
	return q_num;
}
public void setQ_num(int q_num) {
	this.q_num = q_num;
}
public String getQ_title() {
	return q_title;
}
public void setQ_title(String q_title) {
	this.q_title = q_title;
}
public String getQ_name() {
	return q_name;
}
public void setQ_name(String q_name) {
	this.q_name = q_name;
}
public String getQ_date() {
	return q_date;
}
public void setQ_date(String q_date) {
	this.q_date = q_date;
}
public int getQ_views() {
	return q_views;
}
public void setQ_views(int q_views) {
	this.q_views = q_views;
}

public String getQ_content() {
	return q_content;
}
public void setQ_content(String q_content) {
	this.q_content = q_content;
}
public int getS_num() {
	return s_num;
}
public void setS_num(int s_num) {
	this.s_num = s_num;
}



}
