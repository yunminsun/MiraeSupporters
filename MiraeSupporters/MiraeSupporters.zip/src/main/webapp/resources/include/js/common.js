/* 함수명: chkSubmit(유효성체크대상, 메시지내용) * 출력영역: alert으로.* 예시: if(!chkSubmit($('#keyword'),"검색어를")) return;* 
*/
function chkSubmit(item, msg) {
	if (item.val().replace(/\s/g, "") == "") {
		alert(msg + " 입력해주세요.");
		item.val("");
		item.focus();
		return false;
	} else {
		return true;
	}
}
	/* * 함수명: checkForm(유효성체크대상, 메시지내용) * 출력영역: placeholder 속성을이용.* 예시:
	 * if(!chkSubmit($('#keyword'),"검색어를")) return;*
	 */
function checkForm(item, msg) {
	var message = "";
	if (item.val().replace(/\s/g, "") == "") {
		message = msg + " 입력해주세요.";
		item.attr("placeholder", message);
		return false;
	} else {
		return true;
	}
}
	/* * 함수명: formCheck(유효성체크대상, 출력영역, 메시지내용) * 출력영역: 매개변수두번째출력영역에.* 예시:
	 * if(!formCheck($('#keyword'),$('#msg'),"검색어를")) return; 36*
	 */
function formCheck(main, item, msg) {
	if (main.val().replace(/\s/g, "") == "") {
		item.css("color", "#000099").html(msg + " 입력해주세요");
		main.val("");
		return false;
	} else {
		return true;
	}
}/*
	 * 함수명: chkData(유효성체크대상, 메시지내용) * 예시: if (!chkData("#keyword","검색어를"))
	 * return;**/
	 
function chkData(item, msg) {
	if ($(item).val().replace(/\s/g, "") == "") {
		alert(msg + " 입력해주세요.");
		$(item).val("");
		$(item).focus();
		return false;
	} else {
		return true;
	}
}

var pattern = [ "((?=.*[a-zA-Z])(?=.*[0-9]).{6,10})",
		"((?=.*[a-zA-Z])(?=.*[0-9@#$%]).{8,12})", "^\\d{3}-\\d{3,4}-\\d{4}" ];
function inputVerify(index, data, printarea) {
	var data_regExp = new RegExp(pattern[index]);
	var match = data_regExp.exec($(data).val());
	if (match == null) {
		$(printarea).html("입력값이형식에맞지않습니다. 다시입력해주세요.");
		$(data).val("");
		return false;
	} else {
		return true;
	}
}