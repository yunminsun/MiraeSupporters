/*********************************** 이메일 콤보박스 ***********************************/
$(function() {
	$("#s_email_select").change(function() {
		
		var addrselected = $("#s_email_select option:selected").val();
		var clientaddr = $("#s_email_addr").val();
		if (addrselected != "직접입력") {
			$("#s_email_addr").val(addrselected);
		}
		
	});
	
});
